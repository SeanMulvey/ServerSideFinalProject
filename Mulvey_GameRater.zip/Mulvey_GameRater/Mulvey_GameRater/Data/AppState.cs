﻿namespace Mulvey_GameRater.Data
{
    public class AppState
    {
        public int currentUser {  get; set; }
    }
    public class ChildRenderService
    {
        public Action OnLogginChanged { get; set; }

        public void RequestLogginChanged()
        {
            OnLogginChanged?.Invoke();
        }
    }
}

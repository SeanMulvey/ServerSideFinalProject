﻿using Microsoft.EntityFrameworkCore;
using Mulvey_GameRater.Models;

namespace Mulvey_GameRater.Data
{
    public class AppDbContext : DbContext
    {
        protected readonly IConfiguration Config;
        public AppDbContext(IConfiguration config)
        {
            Config = config;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer(Config.GetConnectionString("Default"));
        }

        public DbSet<User> Users { get; set; }  
        public DbSet<Game> Games { get; set; }
        public DbSet<Rating> Ratings {  get; set; }
    }
}

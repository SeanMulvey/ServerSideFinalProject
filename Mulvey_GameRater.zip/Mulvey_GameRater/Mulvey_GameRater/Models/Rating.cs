﻿namespace Mulvey_GameRater.Models
{
    public class Rating
    {
        public int ratingID { get; set; }
        public int userID { get; set; }
        public int gameID { get; set; }
        public double rating {  get; set; }

    }
}

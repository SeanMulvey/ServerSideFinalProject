﻿namespace Mulvey_GameRater.Models
{
    public class Game
    {
        public int gameID {  get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public string icon { get; set; }
        public string iconUrl { get; set; }
        public double avgRating { get; set; }
        public string genreOne { get; set; }
        public string genreTwo { get; set;}
        public string genreThree { get; set;}
    }
}

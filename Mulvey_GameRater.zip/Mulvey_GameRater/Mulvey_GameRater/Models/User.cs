﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Mulvey_GameRater.Models
{
    public class User
    {
        public int userID {  get; set; }
        public string username { get; set; }
        public string email { get; set; }
        public string password { get; set; }

        [NotMapped]
        public List<Rating> ratings { get; set; }

        [NotMapped]
        public List<string> genres { get; set; }

    }
}
